from django.contrib import admin
from .models import UserProject


admin.site.register(UserProject)
